CREATE PROCEDURE chargedUsers @X int, @Y int
AS
	SELECT COUNT(DISTINCT U.id)
	FROM [User] U
	WHERE @X <= (SELECT COUNT(*)
					FROM [Transaction] T
					WHERE T.[type] = 'charge' AND U.id = T.charge_user_id)
	AND @Y >= (SELECT COUNT(*)
					FROM [Transaction] T
					WHERE T.[type] = 'purchase' AND U.id = T.charge_user_id)
go


CREATE PROCEDURE lastChange @X nvarchar(255)
AS 
	SELECT U.modification_date, U.modification_reason
	FROM User_Info UI, [User] U
	WHERE UI.full_name = @X AND U.user_info_id = UI.id_number
go


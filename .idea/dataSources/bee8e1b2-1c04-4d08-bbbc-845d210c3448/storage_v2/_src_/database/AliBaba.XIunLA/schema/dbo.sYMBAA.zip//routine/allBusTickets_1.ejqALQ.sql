CREATE PROCEDURE allBusTickets_1 @Y nvarchar(255), @Z nvarchar(255)
AS 
	SELECT DISTINCT B.company
	FROM Bus B
	WHERE B.departure_city != @Y OR B.destination_city != @Z
go


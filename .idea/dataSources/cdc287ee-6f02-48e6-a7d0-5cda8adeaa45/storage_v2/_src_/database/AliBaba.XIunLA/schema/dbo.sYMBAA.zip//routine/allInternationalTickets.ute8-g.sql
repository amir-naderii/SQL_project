CREATE PROCEDURE allInternationalTickets @X nvarchar(255), @Y nvarchar(255), @Z nvarchar(255),
											@A datetime, @B datetime
AS
	SELECT FT.*
	FROM Flight_Ticket FT, Flight F, International I, Flight_Ticket_Relation FTR
	WHERE I.flight_id = F.id AND F.id = FTR.flight_id AND FTR.flight_ticket_id = FT.id
			AND F.departure_city = @Y AND F.destination_city = @Z AND FT.flight_class = @X
			AND F.travel_date BETWEEN @A AND @B
go


CREATE PROCEDURE reserveHotel_5 @A int
AS 
	SELECT H.*
    FROM Hotel H
    WHERE (SELECT COUNT(DISTINCT HR.[transaction_id])
                        FROM Hotel_Reservation HR, Hotel_Ticket HT
                        WHERE HR.hotel_ticket_id = HT.id AND HT.hotel_id = H.id AND H.stars > @A 
                        )
			=
          (SELECT MAX(X.num) 
            FROM (SELECT COUNT(HR.[transaction_id]) AS num
                    FROM Hotel_Reservation HR, Hotel_Ticket HT, Hotel H
                    WHERE HR.hotel_ticket_id = HT.id AND HT.hotel_id = H.id AND H.stars > @A 
                    GROUP BY H.id
                    ) X)
go


CREATE VIEW User_Spec_View AS
SELECT UI.* 
FROM [dbo].[User_Info] UI INNER JOIN [dbo].[User] U
ON U.user_info_id = UI.id_number
WHERE U.credit > 0
go


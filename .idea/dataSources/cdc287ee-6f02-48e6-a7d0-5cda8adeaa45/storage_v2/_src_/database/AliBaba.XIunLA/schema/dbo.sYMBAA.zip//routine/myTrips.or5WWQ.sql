CREATE PROCEDURE myTrips @X nvarchar(255)
AS
	(SELECT T.[date], T.id, T.amount, 'Flight' AS Reservation_Type
		FROM Fight_Reservation FR, [Transaction] T, [User] U, User_Info UI 
		WHERE FR.transaction_id = T.id AND U.user_info_id = UI.id_number AND
				UI.full_name = @X AND T.charge_user_id = U.id)
	UNION
	(SELECT T.[date], T.id, T.amount, 'Bus' AS Reservation_Type
		FROM Bus_Reservation BR, [Transaction] T, [User] U, User_Info UI 
		WHERE BR.transaction_id = T.id AND U.user_info_id = UI.id_number AND
				UI.full_name = @X AND T.charge_user_id = U.id)
	UNION
	(SELECT T.[date], T.id, T.amount, 'Hotel' AS Reservation_Type
		FROM Hotel_Reservation HR, [Transaction] T, [User] U, User_Info UI 
		WHERE HR.transaction_id = T.id AND U.user_info_id = UI.id_number AND
				UI.full_name = @X AND T.charge_user_id = U.id)
go


CREATE PROCEDURE internationalTickets @X nvarchar(255), @Y nvarchar(255), @C int
AS
	SELECT AVG(LEN(UI.full_name))
	FROM User_Info UI
	WHERE @C < (SELECT COUNT(*)
				FROM International I, Flight F, Flight_Ticket_Relation FTR, Flight_Ticket FT, 
					Fight_Reservation FR, [User] U
				WHERE I.flight_id = F.id AND F.id = FTR.flight_id AND FTR.flight_ticket_id = FT.id
					AND FT.id = FR.flight_ticket_id AND FR.[user_id] = U.id AND U.user_info_id = UI.id_number
					AND F.departure_city = @X AND F.destination_city = @Y)
go


CREATE PROCEDURE userWalletDetail @A nvarchar(255)
AS
	SELECT T.charge_user_id, T.[type]
	FROM [Transaction] T, [User] U, User_Info UI
	WHERE T.charge_user_id = U.id AND UI.id_number = U.user_info_id 
	AND UI.full_name LIKE '%'+ @A AND T.[date] = (SELECT MAX(T.[date])
													FROM [dbo].[Transaction] T
													WHERE U.id = T.charge_user_id)
go


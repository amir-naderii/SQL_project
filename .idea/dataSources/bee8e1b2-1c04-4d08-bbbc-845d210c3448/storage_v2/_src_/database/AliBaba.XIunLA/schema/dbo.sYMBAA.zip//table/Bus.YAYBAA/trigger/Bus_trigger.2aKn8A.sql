CREATE TRIGGER Bus_trigger 
ON Bus
AFTER INSERT
AS
BEGIN 
    SET NOCOUNT ON;
    DECLARE @Capacity INT
    DECLARE @Id INT
    DECLARE @Bus_id INT
    DECLARE @Counter INT = 1;

    SELECT @Capacity = INSERTED.capacity, @Bus_id = INSERTED.id
    FROM INSERTED
    SELECT @Id = MAX(id) 
    FROM Bus_Ticket
    SET @Id = @Id + 1
    IF @Capacity IS NOT NULL
    BEGIN
        WHILE @counter <= @Capacity
        BEGIN
            INSERT INTO Bus_Ticket VALUES(@Id, 1, 300000, @Bus_id, @Counter);
            SET @Id = @Id + 1
            SET @Counter = @Counter + 1;
        END;
    END
END
go


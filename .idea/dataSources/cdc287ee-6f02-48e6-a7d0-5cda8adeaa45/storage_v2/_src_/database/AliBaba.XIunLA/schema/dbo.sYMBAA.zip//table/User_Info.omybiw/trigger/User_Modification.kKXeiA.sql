CREATE TRIGGER User_Modification 
ON User_Info 
AFTER UPDATE 
AS
	BEGIN
	SET NOCOUNT ON;
	DECLARE @id int 
	SELECT @id = INSERTED.id_number
	FROM INSERTED
	UPDATE [User]
	SET [User].modification_date = CURRENT_TIMESTAMP,
		[User].modification_reason = 'Update_Required'
	WHERE @id = [User].user_info_id
	END
go


CREATE TRIGGER Flight_trigger 
ON Flight
AFTER INSERT
AS
BEGIN 
    SET NOCOUNT ON;
    DECLARE @Capacity INT
    DECLARE @Id INT
    DECLARE @Flight_id INT
    DECLARE @Counter INT = 0;

    SELECT @Capacity = INSERTED.capacity, @Flight_id = INSERTED.id
    FROM INSERTED
    SELECT @Id = MAX(id) 
    FROM Flight_Ticket
	SET @Id = @Id + 1
    IF @Capacity IS NOT NULL
    BEGIN
        WHILE @counter <= @Capacity
        BEGIN
            INSERT INTO Flight_Ticket VALUES(@Id, 1, 300000, 'Direct', 'VIP');
            INSERT INTO Flight_Ticket_Relation VALUES(@Id, @Flight_id, @Id);
			SET @Id = @Id + 1
            SET @counter = @counter + 1;
        END;
    END
END
go


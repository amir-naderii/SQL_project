CREATE PROCEDURE reserveHotel_2 @A datetime, @B datetime, @C nvarchar(255)
AS 
	SELECT UI.*
    FROM User_Info UI INNER JOIN [User] U
    ON UI.id_number = U.user_info_id
    WHERE NOT EXISTS ((SELECT H.id
                        FROM Hotel H
                        WHERE H.stars < 3 and H.[address] =  @C) EXCEPT
                        (SELECT H.id
                        FROM Hotel H, Hotel_Reservation HR, Hotel_Ticket HT, [Transaction] T
                        WHERE H.id = HT.hotel_id AND HT.id = HR.hotel_ticket_id AND HR.[user_id] = U.id
                        AND HR.transaction_id = T.id AND T.[date] BETWEEN @A AND @B))
go


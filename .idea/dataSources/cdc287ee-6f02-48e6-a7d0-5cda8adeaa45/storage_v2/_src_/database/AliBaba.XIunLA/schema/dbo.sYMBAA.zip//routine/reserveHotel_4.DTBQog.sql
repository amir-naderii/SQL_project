CREATE PROCEDURE reserveHotel_4 @B nvarchar(255), @C int
AS 
	SELECT UI.*
	FROM User_Info UI, [USER] U, Hotel_Reservation HR, Hotel_Ticket HT, Hotel H 
	WHERE UI.id_number = U.user_info_id AND U.id = HR.[user_id] AND HR.hotel_ticket_id = HT.id
		AND HT.hotel_id = H.id AND H.[address] = @B AND (datediff(day, HT.check_in, HT.check_out) > @C)
go


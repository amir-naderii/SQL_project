CREATE PROCEDURE reserveHotel_1 @N int, @X nvarchar(255), @A datetime, @D datetime,
								@B datetime, @M int, @Y nvarchar(255), @C datetime
AS 
	SELECT UI.*
	FROM User_Info UI
	WHERE @N = (SELECT COUNT(*)
				FROM [User] U, Hotel_Reservation HR, Hotel_Ticket HT, Hotel H
				WHERE UI.id_number = U.id AND U.id = HR.[user_id] AND HR.hotel_ticket_id = HT.id
					AND HT.hotel_id = H.id AND H.[address] = @X AND HT.check_in BETWEEN @A AND @B)
	AND @M = (SELECT COUNT(*)
				FROM [User] U, Bus_Reservation BR, Bus_Ticket BT, Bus B
				WHERE UI.id_number = U.id AND U.id = BR.[user_id] AND BR.bus_ticket_id = BT.id
					AND BT.bus_id = B.id AND B.departure_city = @Y AND B.travel_date BETWEEN @C AND @D)
go


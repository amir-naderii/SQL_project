CREATE PROCEDURE terminalBuses @A nvarchar(255), @B nvarchar(255), @C nvarchar(255),
								@D varchar(255), @E datetime
AS
	SELECT B.*
	FROM Bus B
	WHERE B.departure_terminal = @A AND B.departure_city = @B AND B.destination_city = @C AND
			B.company = @D AND B.travel_date = @E
go


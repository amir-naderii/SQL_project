CREATE PROCEDURE twoTrips @X nvarchar(255), @Y nvarchar(255), @Z varchar(255)
AS	
	SELECT UI.full_name
	FROM User_Info UI
	WHERE ((SELECT F.travel_date
		FROM Domestic D, Flight F, Flight_Ticket_Relation FTR, Flight_Ticket FT, 
			Fight_Reservation FR, [User] U
		WHERE D.flight_id = F.id AND F.id = FTR.flight_id AND FTR.flight_ticket_id = FT.id
			AND FT.id = FR.flight_ticket_id AND FR.[user_id] = U.id AND F.departure_city = @X
			AND F.destination_city = @Y AND U.user_info_id = UI.id_number)
	UNION
	(SELECT B.travel_date
		FROM Bus B, Bus_Ticket BT, Bus_Reservation BR, [User] U
		WHERE B.id = BT.bus_id AND BT.id = BR.bus_ticket_id AND BR.[user_id] = U.id 
			AND B.departure_city = @X AND B.destination_city = @Y AND U.user_info_id = UI.id_number)) < 
	(SELECT F.travel_date
		FROM International I, Flight F, Flight_Ticket_Relation FTR, Flight_Ticket FT, 
			Fight_Reservation FR, [User] U
		WHERE I.flight_id = F.id AND F.id = FTR.flight_id AND FTR.flight_ticket_id = FT.id
			AND FT.id = FR.flight_ticket_id AND FR.[user_id] = U.id AND U.user_info_id = UI.id_number
			AND F.departure_city = @Y AND F.destination_city = @Z)
go


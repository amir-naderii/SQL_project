CREATE TRIGGER Reservation_Trigger
ON [dbo].[Transaction]
AFTER INSERT
AS BEGIN 
	SET NOCOUNT ON;
	DECLARE @Cost int 
	DECLARE @Type varchar(255)
	DECLARE @id int
	SELECT @Cost = INSERTED.amount, @Type = INSERTED.[type], @id=INSERTED.charge_user_id
	FROM INSERTED 
	IF @Type = 'charge'
		BEGIN
		UPDATE [dbo].[User]
		SET credit = credit + @Cost
		WHERE @id = [dbo].[User].id
		END
	ELSE 
		BEGIN
		UPDATE [dbo].[User]
		SET credit = credit - @Cost
		WHERE @id = [dbo].[User].id
		END
END
go


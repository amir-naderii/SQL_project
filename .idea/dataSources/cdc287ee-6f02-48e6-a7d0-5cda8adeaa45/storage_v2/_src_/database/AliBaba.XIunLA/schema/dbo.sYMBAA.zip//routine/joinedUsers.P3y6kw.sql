CREATE PROCEDURE joinedUsers @A datetime, @B datetime, @C int
AS
	SELECT UI.*
	FROM User_Info UI INNER JOIN [User] U
	ON UI.id_number = U.user_info_id
	WHERE @C > (SELECT COUNT(*)
				FROM Fight_Reservation FR, Flight_Ticket FT, Flight_Ticket_Relation FTR, Flight F
				WHERE FR.[user_id] = U.id AND F.id = FTR.flight_id AND FTR.flight_ticket_id = FT.id
						AND FT.id = FR.flight_ticket_id AND F.travel_date > dateadd(month, -1, getdate()))
				+
				(SELECT COUNT(*)
				FROM Bus_Reservation BR, Bus_Ticket BT, Bus B
				WHERE BR.[user_id] = U.id AND BT.id = BR.bus_ticket_id AND BT.bus_id = B.id
					 AND B.travel_date > dateadd(month, -1, getdate()))
	OR U.creation_date BETWEEN @A AND @B
go


CREATE PROCEDURE allDomesticFlights @A nvarchar(255), @B nvarchar(255), @C datetime
AS
	SELECT F.company
	FROM Flight F INNER JOIN Domestic D
	ON F.id = D.flight_id
	WHERE F.departure_city = @A AND F.destination_city = @B AND F.travel_date = @C
go


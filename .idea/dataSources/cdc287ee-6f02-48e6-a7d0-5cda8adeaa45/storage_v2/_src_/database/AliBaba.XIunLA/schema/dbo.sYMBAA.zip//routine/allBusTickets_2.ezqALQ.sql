CREATE PROCEDURE allBusTickets_2 @X nvarchar(255), @Y nvarchar(255), @Z nvarchar(255), @C int
AS
	SELECT BT.*
	FROM Bus_Ticket BT, Bus B
	WHERE B.company = @Z AND BT.bus_id = B.id AND B.departure_city = @X AND
			B.destination_city = @Y AND BT.price < @C AND (B.travel_date = (SELECT MIN(B.travel_date)
							FROM Bus_Ticket BT, Bus B
							WHERE B.company = @Z AND BT.bus_id = B.id AND B.departure_city = @X AND
									B.destination_city = @Y AND BT.price < @C)
			OR B.capacity = (SELECT MAX(B.capacity)
								FROM Bus_Ticket BT, Bus B
								WHERE B.company = @Z AND BT.bus_id = B.id AND B.departure_city = @X AND
									B.destination_city = @Y AND BT.price < @C))
go


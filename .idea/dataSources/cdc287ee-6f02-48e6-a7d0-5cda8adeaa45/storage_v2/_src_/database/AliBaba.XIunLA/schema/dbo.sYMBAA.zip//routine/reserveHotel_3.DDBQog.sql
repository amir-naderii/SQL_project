CREATE PROCEDURE reserveHotel_3 @A nvarchar(255), @B nvarchar(255)
AS 
	SELECT UI.full_name
	FROM User_Info UI
	WHERE (UI.id_number IN (SELECT U.user_info_id
                  FROM [User] U, Hotel_Reservation HR, Hotel_Ticket HT, Hotel H
                  WHERE UI.id_number = U.user_info_id AND U.id = HR.[user_id] AND HR.hotel_ticket_id = HT.id 
				  AND HT.hotel_id = H.id AND H.[address] = @A) AND NOT EXISTS 
				  (SELECT U.user_info_id
                  FROM [User] U, Hotel_Reservation HR, Hotel_Ticket HT, Hotel H
                  WHERE UI.id_number = U.user_info_id AND U.id = HR.[user_id] AND HR.hotel_ticket_id = HT.id 
				  AND HT.hotel_id = H.id AND H.[address] != @A))

    OR (UI.id_number NOT IN ((SELECT U.user_info_id
                  FROM [User] U, Bus_Reservation BR, Bus_Ticket BT, Bus B
                  WHERE UI.id_number = U.user_info_id AND U.id = BR.[user_id] AND BR.bus_ticket_id = BT.id AND
                        BT.bus_id = B.id AND B.Destination_city = @B)
                        UNION
                  (SELECT U.user_info_id
                  FROM [User] U, Fight_Reservation FR, Flight_Ticket FT, Flight_Ticket_Relation FTR, Flight F
                  WHERE UI.id_number = U.user_info_id AND U.id = FR.[user_id] AND FR.flight_ticket_id = FT.id AND
                        FT.id = FTR.flight_ticket_id AND FTR.flight_id = F.id AND F.destination_city = @B)))
	ORDER BY UI.full_name ASC
go


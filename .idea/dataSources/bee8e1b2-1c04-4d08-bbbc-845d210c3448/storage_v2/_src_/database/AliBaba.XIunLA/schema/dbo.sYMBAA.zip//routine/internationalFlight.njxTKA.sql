CREATE PROCEDURE internationalFlight @X int, @Y nvarchar(255), @Z varchar(255), @N int
AS	
	SELECT TOP(@X) F.*
	FROM Flight F, International I, Flight_Ticket_Relation FTR, Flight_Ticket FT
	WHERE I.flight_id = F.id AND F.id = FTR.flight_id AND FTR.flight_ticket_id = FT.id
		AND F.departure_city = @Y AND F.destination_city = @Z AND 
		F.travel_date > (select dateadd(month, -@N, getdate()))
	ORDER BY FT.price DESC
go


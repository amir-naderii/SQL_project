CREATE PROCEDURE purchasedTickets @A nvarchar(255), @B nvarchar(255), @X varchar(255)
AS 
	SELECT COUNT(DISTINCT FR.[user_id])
	FROM [dbo].[Fight_Reservation] FR, Flight_Ticket FT, Flight_Ticket_Relation FTR, Flight F
	WHERE FT.flight_type = @X AND F.departure_city = @A AND F.destination_city = @B AND 
			F.id = FTR.flight_id AND FTR.flight_ticket_id = FT.id AND FT.id = FR.flight_ticket_id
go


CREATE PROCEDURE hotelOrBusUsers @A int, @B nvarchar(255)
AS
	SELECT AVG(U.credit)
	FROM [USER] U
	WHERE @A <=
	(SELECT COUNT(*)
		FROM [Transaction] T, Bus_Reservation BR, Bus B, Bus_Ticket BT
		WHERE U.id = T.charge_user_id AND T.id = BR.transaction_id AND BR.bus_ticket_id = BT.id
				AND BT.bus_id = B.id AND B.departure_city = @B)
	AND @A <= (SELECT COUNT(*)
				FROM [Transaction] T, Hotel_Reservation HR, Hotel H, Hotel_Ticket HT
				WHERE U.id = T.charge_user_id AND T.id = HR.transaction_id AND HR.hotel_ticket_id = HT.id
				AND HT.hotel_id = H.id AND H.[address] = @B)
go

